#include <iostream>
using namespace std;

int main () {
  int i, j;
  cin >> i;
  cin >> j;
  cout << i+j;
  cout << "\n";
  return 0;
}
