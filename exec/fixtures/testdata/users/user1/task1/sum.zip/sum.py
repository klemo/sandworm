import sys

print(sum([int(line) for line in sys.stdin]))
